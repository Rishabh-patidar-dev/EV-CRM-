"use client";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarItem,
  SidebarCollapsibleItem,
  SidebarProvider,
  SidebarHeader,
  SidebarTrigger,
  useSidebar,
} from "@repo/ui";
import Image from "next/image";
import logoWhite from "../app/assets/images/logos/logo_synkro_white.png";
import logoSymbolWhite from "../app/assets/images/logos/logo_symbol_white.png";
import {
  ChartNoAxesCombined,
  Users,
  Settings,
  Megaphone,
  FileText,
  Bot,
  ListChecks,
  UserCheck,
  Share2,
  Building2,
  BookUser,
  Mail,
  MessageCircle,
  UserLock,
  TrendingUp,
  BarChart,
  Package,
  ReceiptText,
  LayoutTemplate,
  Layers,
  ShoppingCart,
  BookAIcon,
  BookCheckIcon,
  ClipboardCheck,
} from "lucide-react";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { useIsAdminRole } from "./guards/RoleGuard";

function SidebarBrand() {
  const { open } = useSidebar();
  return open ? (
    <Image
      src={logoWhite}
      alt="Synkro CRM"
      height={28}
      className="h-7 w-auto object-contain"
      priority
    />
  ) : (
    <Image
      src={logoSymbolWhite}
      alt="Synkro CRM"
      width={28}
      height={28}
      className="h-7 w-7 object-contain"
      priority
    />
  );
}

export function AppSidebar() {
  const pathname = usePathname();
  const [isClient, setIsClient] = useState(false);
  const isAdmin = useIsAdminRole();

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Check if we're on any lead management route
  const isLeadManagementActive = pathname.startsWith("/leads");
  const isCampaignsActive = pathname.startsWith("/campaigns");
  const isSalesManagementActive = pathname.startsWith("/sales");
  const isLandingPageActive =
    pathname === "/landing-page" ||
    pathname.startsWith("/landing-page-trackers");

  return (
    <SidebarProvider>
      <Sidebar className="h-full">
        <SidebarHeader>
          <SidebarBrand />
          <SidebarTrigger />
        </SidebarHeader>
        <SidebarContent className="[&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <SidebarGroup title="">
            <SidebarItem
              icon={ChartNoAxesCombined as any}
              label="Dashboard"
              href="/"
              active={isClient && pathname === "/"}
            />
            <SidebarCollapsibleItem
              icon={LayoutTemplate as any}
              label="Landing Page"
              active={isClient && isLandingPageActive}
              defaultOpen={isClient && isLandingPageActive}
            >
              <SidebarItem
                label="Landing Page Trackers"
                href="/landing-page-trackers"
                active={
                  isClient && pathname.startsWith("/landing-page-trackers")
                }
                icon={Layers as any}
              />
              <SidebarItem
                label="Landing Page Builder"
                href="https://app.landingi.com/landings"
                target="_blank"
                active={isClient && pathname === "/landing-page"}
                icon={FileText as any}
              />
            </SidebarCollapsibleItem>
            <SidebarCollapsibleItem
              icon={Users as any}
              label="Lead Management"
              active={isClient && isLeadManagementActive}
              defaultOpen={isClient && isLeadManagementActive}
            >
              <SidebarItem
                label="Lead Master"
                href="/leads/lead-master"
                active={isClient && pathname === "/leads/lead-master"}
                icon={ListChecks as any}
              />
              <SidebarItem
                label="Assigned Leads"
                href="/leads/assigned"
                active={isClient && pathname === "/leads/assigned"}
                icon={UserCheck as any}
              />
              <SidebarItem
                label="Unassigned Leads"
                href="/leads/unassigned-leads"
                active={isClient && pathname === "/leads/unassigned-leads"}
                icon={Share2 as any}
              />
              <SidebarItem
                label="Accounts"
                href="/leads/accounts"
                active={isClient && pathname === "/leads/accounts"}
                icon={Building2 as any}
              />
              <SidebarItem
                label="Contacts"
                href="/leads/contacts"
                active={isClient && pathname === "/leads/contacts"}
                icon={BookUser as any}
              />
            </SidebarCollapsibleItem>
            <SidebarCollapsibleItem
              icon={Megaphone as any}
              label="Campaign Management"
              active={isClient && isCampaignsActive}
              defaultOpen={isClient && isCampaignsActive}
            >
              <SidebarItem
                label="Email Campaigns"
                href="/campaigns/email"
                active={isClient && pathname.startsWith("/campaigns/email")}
                icon={Mail as any}
              />
              <SidebarItem
                label="WhatsApp Campaigns"
                href="/campaigns/whatsapp"
                active={isClient && pathname.startsWith("/campaigns/whatsapp")}
                icon={MessageCircle as any}
              />
              <SidebarItem
                label="Segments"
                href="/campaigns/segments"
                active={isClient && pathname.startsWith("/campaigns/segments")}
                icon={ListChecks as any}
              />
            </SidebarCollapsibleItem>
            <SidebarCollapsibleItem
              icon={TrendingUp as any}
              label="Sales Management"
              active={isClient && isSalesManagementActive}
              defaultOpen={isClient && isSalesManagementActive}
            >
              {/*<SidebarItem
                label="Dashboard"
                href="/sales/dashboard"
                active={isClient && pathname === '/sales/dashboard'}
                icon={BarChart as any}
              />*/}
              <SidebarItem
                label="Opportunities"
                href="/sales/opportunities"
                active={isClient && pathname.startsWith("/sales/opportunities")}
                icon={BookAIcon as any}
              />
              <SidebarItem
                label="Quotes"
                href="/sales/quotes"
                active={isClient && pathname.startsWith("/sales/quotes")}
                icon={ReceiptText as any}
              />
              <SidebarItem
                label="Orders"
                href="/sales/orders"
                active={isClient && pathname.startsWith("/sales/orders")}
                icon={ShoppingCart as any}
              />
              <SidebarItem
                label="Product Configuration"
                href="/sales/products"
                active={isClient && pathname.startsWith("/sales/products")}
                icon={Package as any}
              />
              <SidebarItem
                label="Price Books"
                href="/sales/price-books"
                active={isClient && pathname.startsWith("/sales/price-books")}
                icon={BookCheckIcon as any}
              />
              <SidebarItem
                label="Approvals"
                href="/sales/approvals"
                active={isClient && pathname.startsWith("/sales/approvals")}
                icon={ClipboardCheck as any}
              />
            </SidebarCollapsibleItem>
            <SidebarItem
              icon={Bot as any}
              label="Chatbot"
              href="/chatbot"
              active={isClient && pathname === "/chatbot"}
            />
            {!isAdmin && (
              <SidebarItem
                icon={UserLock as any}
                label="User Management"
                href="/admin/user-management"
                active={isClient && pathname === "/admin/user-management"}
              />
            )}
            <SidebarItem
              icon={Settings as any}
              label="Settings"
              href="/settings"
              active={isClient && pathname === "/settings"}
            />
            {/* Settings can have notification management and other user related settings such as name */}
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          <p className="text-xs font-medium text-brand-indigo/80">
            © {new Date().getFullYear()} SynkroCRM
          </p>
        </SidebarFooter>
      </Sidebar>
    </SidebarProvider>
  );
}
