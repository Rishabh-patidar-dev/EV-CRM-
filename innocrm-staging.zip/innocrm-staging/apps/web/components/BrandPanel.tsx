"use client";

import Image from "next/image";
import ParticleNetwork from "./ParticleNetwork";
import brandHero from "../app/assets/images/login-brand-panel.png";

/**
 * Right-hand marketing panel on the login screen.
 * Uses the exact hi-res brand artwork supplied by design (headline, orbit
 * diagram, dashboard mockup and security badge are all baked into the
 * image itself) and layers the same animated particle network used
 * elsewhere on the login page on top of it.
 */
export default function BrandPanel() {
  return (
    <div className="relative hidden h-full overflow-hidden md:block">
      <Image
        src={brandHero}
        alt="One Platform. Every Connection. Endless Opportunities."
        fill
        priority
        className="object-cover object-top"
      />
      <ParticleNetwork opacity={0.35} />
    </div>
  );
}
